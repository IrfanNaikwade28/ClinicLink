import 'dotenv/config';
import connectDB from '../config/mongodb.js';
import doctorModel from '../models/doctorModel.js';

const seed = async () => {
  try {
    console.log('Starting doctor seeding...');
    await connectDB();
    console.log('Connected to MongoDB');

    // Clear existing doctors for a clean slate
    await doctorModel.deleteMany({});
    console.log('Existing doctors cleared');

    let passwordHash = 'doctor123';
    try {
      const bcryptMod = (await import('bcrypt')).default;
      passwordHash = await bcryptMod.hash('doctor123', 10);
    } catch (e) {
      console.warn('bcrypt not available, seeding with plaintext passwords. Doctor login may not work.');
    }

    const now = Date.now();

    // Based on clientside/src/assets/assets.js
    const doctors = [
      {
        name: 'Dr. Richard James',
        speciality: 'General physician',
        degree: 'MBBS',
        experience: '4 Years',
        fees: 50,
        address: { line1: '17th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=11',
      },
      {
        name: 'Dr. Emily Larson',
        speciality: 'Gynecologist',
        degree: 'MBBS',
        experience: '3 Years',
        fees: 60,
        address: { line1: '27th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=12',
      },
      {
        name: 'Dr. Sarah Patel',
        speciality: 'Dermatologist',
        degree: 'MBBS',
        experience: '1 Years',
        fees: 30,
        address: { line1: '37th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=13',
      },
      {
        name: 'Dr. Christopher Lee',
        speciality: 'Pediatricians',
        degree: 'MBBS',
        experience: '2 Years',
        fees: 40,
        address: { line1: '47th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=14',
      },
      {
        name: 'Dr. Jennifer Garcia',
        speciality: 'Neurologist',
        degree: 'MBBS',
        experience: '4 Years',
        fees: 50,
        address: { line1: '57th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=15',
      },
      {
        name: 'Dr. Andrew Williams',
        speciality: 'Neurologist',
        degree: 'MBBS',
        experience: '4 Years',
        fees: 50,
        address: { line1: '57th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=16',
      },
      {
        name: 'Dr. Christopher Davis',
        speciality: 'General physician',
        degree: 'MBBS',
        experience: '4 Years',
        fees: 50,
        address: { line1: '17th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=17',
      },
      {
        name: 'Dr. Timothy White',
        speciality: 'Gynecologist',
        degree: 'MBBS',
        experience: '3 Years',
        fees: 60,
        address: { line1: '27th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=18',
      },
      {
        name: 'Dr. Ava Mitchell',
        speciality: 'Dermatologist',
        degree: 'MBBS',
        experience: '1 Years',
        fees: 30,
        address: { line1: '37th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=19',
      },
      {
        name: 'Dr. Jeffrey King',
        speciality: 'Pediatricians',
        degree: 'MBBS',
        experience: '2 Years',
        fees: 40,
        address: { line1: '47th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=20',
      },
      {
        name: 'Dr. Zoe Kelly',
        speciality: 'Gastroenterologist',
        degree: 'MBBS',
        experience: '4 Years',
        fees: 50,
        address: { line1: '57th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=21',
      },
      {
        name: 'Dr. Patrick Harris',
        speciality: 'Neurologist',
        degree: 'MBBS',
        experience: '4 Years',
        fees: 50,
        address: { line1: '57th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=22',
      },
      {
        name: 'Dr. Chloe Evans',
        speciality: 'General physician',
        degree: 'MBBS',
        experience: '4 Years',
        fees: 50,
        address: { line1: '17th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=23',
      },
      {
        name: 'Dr. Ryan Martinez',
        speciality: 'Gynecologist',
        degree: 'MBBS',
        experience: '3 Years',
        fees: 60,
        address: { line1: '27th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=24',
      },
      {
        name: 'Dr. Amelia Hill',
        speciality: 'Dermatologist',
        degree: 'MBBS',
        experience: '1 Years',
        fees: 30,
        address: { line1: '37th Cross, Richmond', line2: 'Circle, Ring Road, London' },
        image: 'https://i.pravatar.cc/300?img=25',
      },
    ].map((doc, i) => ({
      ...doc,
      email: `${doc.name.toLowerCase().replace(/[^a-z]+/g, '.')}@clinic.com`,
      password: passwordHash,
      date: now + i,
    }));

  const created = await doctorModel.insertMany(doctors);
  console.log(`Inserted ${created.length} doctors.`);
    process.exit(0);
  } catch (err) {
  console.error('Seeding failed:', err);
    process.exit(1);
  }
};

seed();
import "dotenv/config";
import bcrypt from "bcrypt";
import connectDB from "../config/mongodb.js";
import doctorModel from "../models/doctorModel.js";

const run = async () => {
  try {
    await connectDB();

    const passwordHash = await bcrypt.hash("password123", 10);

    const now = Date.now();

    const docs = [
      {
        name: "Dr. Olivia Martin",
        email: "olivia.martin@cliniclink.local",
        password: passwordHash,
        image:
          "https://images.unsplash.com/photo-1550831107-1553da8c8464?q=80&w=600&auto=format&fit=crop",
        speciality: "General physician",
        degree: "MBBS, MD",
        experience: "7 years",
        about:
          "General physician with a focus on preventive care and chronic condition management.",
        available: true,
        fees: 40,
        address: {
          line1: "123 Wellness Ave",
          city: "Springfield",
          state: "IL",
          country: "USA",
          pincode: "62701",
        },
        date: now,
      },
      {
        name: "Dr. Ethan Johnson",
        email: "ethan.johnson@cliniclink.local",
        password: passwordHash,
        image:
          "https://images.unsplash.com/photo-1606811971652-c7b8463d79a0?q=80&w=600&auto=format&fit=crop",
        speciality: "Gynecologist",
        degree: "MBBS, MS (OBGYN)",
        experience: "9 years",
        about:
          "Compassionate gynecologist specializing in prenatal care and minimally invasive procedures.",
        available: true,
        fees: 55,
        address: {
          line1: "45 Care Blvd",
          city: "Austin",
          state: "TX",
          country: "USA",
          pincode: "73301",
        },
        date: now,
      },
      {
        name: "Dr. Sophia Patel",
        email: "sophia.patel@cliniclink.local",
        password: passwordHash,
        image:
          "https://images.unsplash.com/photo-1551601651-2a8555f1a136?q=80&w=600&auto=format&fit=crop",
        speciality: "Dermatologist",
        degree: "MBBS, MD (Dermatology)",
        experience: "6 years",
        about:
          "Dermatologist focused on acne, eczema, and cosmetic dermatology treatments.",
        available: true,
        fees: 50,
        address: {
          line1: "78 SkinCare St",
          city: "San Diego",
          state: "CA",
          country: "USA",
          pincode: "92101",
        },
        date: now,
      },
      {
        name: "Dr. Liam Chen",
        email: "liam.chen@cliniclink.local",
        password: passwordHash,
        image:
          "https://images.unsplash.com/photo-1537368910025-700350fe46c7?q=80&w=600&auto=format&fit=crop",
        speciality: "Pediatricians",
        degree: "MBBS, DCH",
        experience: "8 years",
        about:
          "Pediatrician dedicated to child wellness, vaccinations, and developmental care.",
        available: true,
        fees: 45,
        address: {
          line1: "12 Happy Kids Ln",
          city: "Seattle",
          state: "WA",
          country: "USA",
          pincode: "98101",
        },
        date: now,
      },
      {
        name: "Dr. Ava Thompson",
        email: "ava.thompson@cliniclink.local",
        password: passwordHash,
        image:
          "https://images.unsplash.com/photo-1527613426441-4da17471b66d?q=80&w=600&auto=format&fit=crop",
        speciality: "Neurologist",
        degree: "MBBS, DM (Neurology)",
        experience: "10 years",
        about:
          "Neurologist experienced with migraine, epilepsy, and neurodegenerative disorders.",
        available: true,
        fees: 70,
        address: {
          line1: "9 Neuron Park",
          city: "Boston",
          state: "MA",
          country: "USA",
          pincode: "02108",
        },
        date: now,
      },
      {
        name: "Dr. Noah Garcia",
        email: "noah.garcia@cliniclink.local",
        password: passwordHash,
        image:
          "https://images.unsplash.com/photo-1622253692010-333f2da6031d?q=80&w=600&auto=format&fit=crop",
        speciality: "Gastroenterologist",
        degree: "MBBS, DM (Gastro)",
        experience: "11 years",
        about:
          "Gastroenterologist focusing on IBS, reflux disease, and therapeutic endoscopy.",
        available: true,
        fees: 65,
        address: {
          line1: "56 Digestive Way",
          city: "Chicago",
          state: "IL",
          country: "USA",
          pincode: "60601",
        },
        date: now,
      },
    ];

    // Only insert if none exist
    const count = await doctorModel.countDocuments();
    if (count === 0) {
      await doctorModel.insertMany(docs);
      console.log(`Inserted ${docs.length} doctors.`);
    } else {
      console.log(`Doctors already exist (${count}). Skipping insert.`);
    }
  } catch (err) {
    console.error("Seed failed:", err.message);
  } finally {
    process.exit(0);
  }
};

run();
